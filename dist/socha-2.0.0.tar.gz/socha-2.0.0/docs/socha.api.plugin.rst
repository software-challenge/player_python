socha.api.plugin package
========================

Submodules
----------

socha.api.plugin.penguins module
--------------------------------

.. automodule:: socha.api.plugin.penguins
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: socha.api.plugin
   :members:
   :undoc-members:
   :show-inheritance:
