socha package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   socha.api

Submodules
----------

socha.starter module
--------------------

.. automodule:: socha.starter
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: socha
   :members:
   :undoc-members:
   :show-inheritance:
