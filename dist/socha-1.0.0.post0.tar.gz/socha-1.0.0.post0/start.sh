#!/bin/sh
. venv/bin/activate
python ./logic.py "$@"
